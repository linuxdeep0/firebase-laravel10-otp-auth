<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Registration</title>
	<link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
	    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>


<div class="container py-5">
	<div class="row">
		<div class="col-md-4 mx-auto">
			<div class="p-3 bg-light border rounded-2">
				<h1 class="fs-4 fw-semibold text-center">User Registration</h1>

				<div>
					<div class="alert alert-danger" id="error" style="display: none;"></div>
					<div class="alert alert-success" id="successOtpAuth" style="display: none;"></div>
				</div>

				<div class="registration_div">
					<div class="mb-3">
						<label class="form-label">Name</label>
						<input type="text" id="full_name" class="form-control" placeholder="Enter your full name">
					</div>
					<div class="mb-3">
						<label class="form-label">Phone Number</label>
						<div class="input-group mb-3">
						  <span class="input-group-text" >+91</span>
						  <input type="text" class="form-control" id="number" placeholder="Enter your phone number">
						</div>
					</div>
					<div class="mb-3">
						<div id="recaptcha-container"></div>
					</div>
					<div class="mb-3">
						<button type="button" class="btn btn-primary mt-3" onclick="sendOTP();">Next</button>
					</div>
				</div>
				<div class="verification_div">	
					<input type="text" id="verification" class="form-control" placeholder="Verification code">
                	<button type="button" class="btn btn-primary mt-3" onclick="verify()">Verify code</button>
				</div>

				


			</div>
		</div>
	</div>
</div>



<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

<script type="module">
  const firebaseConfig = {
    apiKey: "AIzaSyCF-0CGE6puvm_Q9vf2DsezRlPenUM1tck",
    authDomain: "laravel-auth-app-aa4b7.firebaseapp.com",
    projectId: "laravel-auth-app-aa4b7",
    storageBucket: "laravel-auth-app-aa4b7.appspot.com",
    messagingSenderId: "287498432127",
    appId: "1:287498432127:web:062309829ea8987064594a",
    measurementId: "G-8DMF1XCTJF"
  };
  firebase.initializeApp(firebaseConfig);


</script>

<script>
    window.onload = function () {
        render();
        $('.verification_div').hide();
    };
 function render() {
        window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
        recaptchaVerifier.render();
    }
        function sendOTP() {
            var number = $("#number").val();
          	number = '+91'+number;
            firebase.auth().signInWithPhoneNumber(number, window.recaptchaVerifier).then(function (confirmationResult) {
                window.confirmationResult = confirmationResult;
                coderesult = confirmationResult;
                console.log(coderesult);
                $("#successOtpAuth").text("Message sent");
                $("#successOtpAuth").show();
                $('.registration_div').hide();
                $('.verification_div').show();
            }).catch(function (error) {
                $("#error").text(error.message);
                $("#error").show();
            });
        }
        function verify() {
            var code = $("#verification").val();
            coderesult.confirm(code).then(function (result) {
                var user = result.user;
                console.log(user);
                $("#successOtpAuth").text("Auth is successful");
                $("#successOtpAuth").show();

                registerUser();

            }).catch(function (error) {
                $("#error").text(error.message);
                $("#error").show();
            });
        }


const registerUser = () => {

	const name = $('#full_name').val();
	const number = $('#number').val();
	const otp = $('#verification').val();

	const registerUrl = "{{route('home.register')}}";
	$.ajax({
		headers: {
		    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
		'method' : 'POST',
		'url' : registerUrl,
		'data':{name,number,otp},
		success:function(data){
			 $('.verification_div').hide();
		    $("#successOtpAuth").text("User Registration successful!");
             $("#successOtpAuth").show();
		},error:function(){
			alert('request not send');

		}
	})

}


    </script>


</body>
</html>