<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    //
    public function index()
    {
        return view('front-end.home');
    }

    // Register

    public function register(Request $request)
    {
        $insertData = [ 
                            'name' => $request->input('name'),
                            'phone' => $request->input('number'),
                            'otp' => $request->input('otp'),
                        ];
        if(DB::table('users')->insert($insertData))
        {
            return ['message' => 'User registerd!'];
        }
        return ['message' => ''];
    }
}
